const TelegramBot = require('node-telegram-bot-api');


const token = '6416745223:AAFuI9TwJHvfgfqVHiErqzRP2uFs03tH7G0';


const bot = new TelegramBot(token, {polling: true});


bot.onText(/\/echo (.+)/, (msg, match) => {
 

  const chatId = msg.chat.id;
  const resp = match[1]; 


  bot.sendMessage(chatId, resp);
  bot.sendPhoto(chatId, resp);
});


bot.on('message', (msg) => {
  const chatId = msg.chat.id;

  if(msg.photo){
    bot.downloadFile(msg.photo, '/image')
  }
  
  bot.sendMessage(chatId, 'Olá! Como posso ajudar?');
  bot.sendPhoto(chatId, "https://www.google.com/imgres?imgurl=https%3A%2F%2Fstatic.zerochan.net%2FRuby.Rose.full.2178749.jpg&tbnid=m14rihhSkkc7wM&vet=12ahUKEwiQqMjWhd2EAxW1N7kGHR6FBMUQMygbegQIARBt..i&imgrefurl=https%3A%2F%2Fwww.zerochan.net%2F2178749&docid=yh3o2yeNSNJMmM&w=1800&h=1800&q=rwby%20ruby%20rose%20image%20animation&ved=2ahUKEwiQqMjWhd2EAxW1N7kGHR6FBMUQMygbegQIARBt", {caption: "Oi"});
});

